package com.example.democontroller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping

public class Vamshiexample1Application{
	private String body;

	@GetMapping
	public ResponseEntity<String>hello(){
		
		return ResponseEntity.ok(body:"hello from secure end point");
		
	}
}
